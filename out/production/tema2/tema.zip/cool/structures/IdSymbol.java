package cool.structures;

public class IdSymbol extends Symbol {
    public IdSymbol(String name, String type) {
        super(name, type);
    }
}
