package cool.compiler.ast;

import org.antlr.v4.runtime.Token;

public abstract class ASTExpr extends ASTNode {
    public Token token;
}
