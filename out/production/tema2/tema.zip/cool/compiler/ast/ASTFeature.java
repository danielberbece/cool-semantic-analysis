package cool.compiler.ast;


public abstract class ASTFeature extends ASTNode {

}
